************************************************************************************************************************************
		PDIFF Readme - Please go through this for high level info and options
			(**************** Utilize apache open source  ************)
		PDF Comparator - Supports Text , Image , Font , Color , Alignment comparison
************************************************************************************************************************************
	
	File			-	Description
	
	Tool.zip		-	Contains the Standalone Jar (Executable) with different .bat files and Sample configurations
	PDiffTest.zip		-	Sample integration setup (Includes the jar files)
	Demo.zip		-	Sample input files with Configuration for Selective comparison and CSV file for Test case execution 
	Jar.zip			-	Contains the support jar only.  Move this only if you don't have local repository at your site or all jars are not present (This is not required if you have moved PDiffTest.zip)
	Jars used 		-	commons-io-2.7.jar ,commons-logging-1.2.jar,commons-text-1.9.jar,fontbox-2.0.19.jar,pdfbox-2.0.19.jar,pdfbox-tools-2.0.19.jar,preflight-2.0.19.jar,pdfbox-debugger-2.0.19.jar



PDiff Execution using CMD - All parameters passed (Input/Sourcefolder, Referencefolder,ResultFolder,FolderMode,Font,Color,Space,WhiteSpaceRemoved,SelectiveComparison,ConfigFolder)

	REM call java -jar PDiff.jar b c:\demo\source c:\demo\reference c:\demo\result y y y y y y c:\demo\config
	REM call java -jar PDiff.jar b c:\demo\source\logocolor.pdf c:\demo\reference\logocolor.pdf c:\demo\result n y y y y y c:\demo\config

PDiff Execution via UI 
	REM call java -jar Pdiff.jar 
	REM call java -jar Pdiff.jar C:\Demo\Source\ C:\Demo\Reference\ C:\Demo\Result\		

PDiff Config Generator / PDF X-Y coordinates
	REM call java -jar Pdiff.jar c 
or
	REM call java -jar Pdiff.jar dynamic

PDiff Form fields Extraction -- See "PDF Forms - Sample PDF.zip" for sample PDF with form fields

	Rem call java -jar Pdiff.jar ef inputFilepath 
	call java -jar Pdiff.jar ef "C:\Demo\Source\pdf_form_maker_new.pdf" 
	Rem call java -jar Pdiff.jar ef inputFilepath fieldKey
	call java -jar Pdiff.jar ef "C:\Demo\Source\pdf_form_maker_new.pdf" "Text 38"
	call pause
	Rem call java -jar Pdiff.jar ef inputFilepath 
	call java -jar Pdiff.jar epf "C:\Demo\Source\pdf_form_maker_new.pdf" 
	Rem call java -jar Pdiff.jar epf inputFilepath fieldKey
	call java -jar Pdiff.jar epf "C:\Demo\Source\pdf_form_maker_new.pdf" "Text 38"

PDiff Extract content into Text file 
	Rem call java -jar Pdiff.jar e inputFilepath outputfileName	
	REM call java -jar Pdiff.jar e "C:\Demo\Reference\Writing a Formal Letter.pdf" alltext

	Rem call java -jar Pdiff.jar e inputFilepath outputfileName pageNo
	call java -jar Pdiff.jar e "C:\Demo\Reference\Writing a Formal Letter.pdf" pagetext 1

	Rem call java -jar Pdiff.jar e inputFilepath outputfileName pageNo x y width height 
	call java -jar Pdiff.jar e "C:\Demo\Reference\Writing a Formal Letter.pdf" 1 0 0 100 100 

PDiff Create Image of pages 
	Rem call java -jar Pdiff.jar pageImage inputFilepath destinationFolder OutputNamePrefix	
	call java -jar Pdiff.jar pageImage "C:\Demo\Reference\Writing a Formal Letter.pdf" "" ""
	
	Rem call java -jar Pdiff.jar pageImage inputFilepath pageNo destinationFolder OutputNamePrefix	
	call java -jar Pdiff.jar pageImage "C:\Demo\Reference\Writing a Formal Letter.pdf" 1 "" ""

	Rem call java -jar Pdiff.jar pageImage inputFilepath pageNo x y width height destinationFolder OutputNamePrefix	  
	call java -jar Pdiff.jar pageImage "C:\Demo\Reference\Writing a Formal Letter.pdf" 1 0 0 100 100 "" ""

PDiff Merge tool - Combines PDF files into one large file
	Rem java -jar Pdiff.jar m  inputfolder outputfileName 		-- This combines files on OS default order 
	call java -jar Pdiff.jar m "c:\Demo\Reference" combinedName 

	Rem java -jar Pdiff.jar m  inputfolder outputfileName Time	-- This is to combine files based on last modified time
	call java -jar Pdiff.jar m "c:\Demo\source" combinedTime Time

PDiff Split PDF file - One file per page 
	REM call java -jar Pdiff.jar s "C:\Demo\Reference\Notice.pdf"  
	REM call java -jar Pdiff.jar s "C:\Demo\Reference\Notice.pdf" "C:\Demo\Split"

PDiff Text - Text comparison 
	call java -jar Pdiff.jar tdiff "C:\Demo\Config\RefPage.txt" "C:\Demo\Config\SourcePage.txt"
	call java -jar Pdiff.jar tdiff "C:\Demo\Config\RefPage.txt" "C:\Demo\Config\SourcePage.txt" diffFile



